import javax.swing.*;

/**
 * Created by nt-user1 on 24.05.2016.
 */
public class Level {
    private JTable table1;
}

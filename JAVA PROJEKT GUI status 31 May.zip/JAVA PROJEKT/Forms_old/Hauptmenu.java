import javax.swing.*;

/**
 * Created by nt-user1 on 24.05.2016.
 */
public class Hauptmenu {
    private JTextField hauptmenuTextField;
    private JButton creditsButton;
    private JButton spielBeendenButton;
    private JButton spielStartenButton;
    private JButton highscoreButton;
    private JButton spielLadenButton;
    private JButton tutorialButton;
}

import javax.swing.*;

/**
 * Created by nt-user1 on 24.05.2016.
 */
public class Highscore {
    private JList list1;
    private JPanel panel1;
}

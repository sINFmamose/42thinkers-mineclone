import javax.swing.*;

/**
 * Created by nt-user1 on 24.05.2016.
 */
public class Credits {
    private JPanel panel1;
}

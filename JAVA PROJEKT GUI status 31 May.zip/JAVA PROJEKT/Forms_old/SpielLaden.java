import javax.swing.*;

/**
 * Created by nt-user1 on 24.05.2016.
 */
public class SpielLaden {
    private JButton letztenSpielstandLadenButton;
    private JPanel panel1;
}

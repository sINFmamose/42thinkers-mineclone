/**
 * Created by perdu on 20.05.16.
 */
public class main {

    public static void main(String[] args) {

        Hauptmenue hauptmenue = new Hauptmenue();
    }
}